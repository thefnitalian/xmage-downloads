@echo off
setlocal EnableExtensions
set "BASE=%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%BASE%TOOLS\Daily-Compatibility-Updater.ps1"
exit /b %ERRORLEVEL%
