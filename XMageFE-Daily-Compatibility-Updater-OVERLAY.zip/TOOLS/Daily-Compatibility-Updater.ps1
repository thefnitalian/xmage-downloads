param([switch]$RunNow)

$ErrorActionPreference = 'Stop'
$edition = Split-Path -Parent $PSScriptRoot
$loader = Join-Path $edition 'xmage-mod-loader'
$reportDir = Join-Path $loader 'reports\snapshot-guard'
$historyDir = Join-Path $reportDir 'daily-history'

function Invoke-CompatibilityUpdate {
    New-Item -ItemType Directory -Force -Path $historyDir | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $archive = Join-Path $historyDir $stamp
    New-Item -ItemType Directory -Force -Path $archive | Out-Null

    foreach ($side in @('client', 'server')) {
        $old = Join-Path $reportDir "report-$side.txt"
        if (Test-Path -LiteralPath $old) {
            Copy-Item -LiteralPath $old -Destination (Join-Path $archive "previous-$side.txt")
        }
    }

    $results = @{}
    foreach ($side in @('client', 'server')) {
        $check = Join-Path $loader "check-$side.bat"
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $env:ComSpec
        $psi.Arguments = "/d /c `"echo.^|`"$check`"`""
        $psi.WorkingDirectory = $edition
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $process = [System.Diagnostics.Process]::Start($psi)
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()
        Set-Content -LiteralPath (Join-Path $archive "$side-console.txt") -Value ($stdout + $stderr) -Encoding UTF8
        $results[$side] = $process.ExitCode
    }

    $summary = New-Object System.Collections.Generic.List[string]
    $blocked = New-Object System.Collections.Generic.List[string]
    $profile = [ordered]@{
        generatedAt = (Get-Date).ToUniversalTime().ToString('o')
        mode = 'verified-daily-compatibility'
        client = [ordered]@{}
        server = [ordered]@{}
    }

    foreach ($side in @('client', 'server')) {
        $report = Join-Path $reportDir "report-$side.txt"
        if (!(Test-Path -LiteralPath $report)) {
            $blocked.Add("$side`: compatibility checker did not produce a report")
            continue
        }
        Copy-Item -LiteralPath $report -Destination (Join-Path $archive "report-$side.txt")
        $lines = @(Get-Content -LiteralPath $report)
        # SnapshotGuard reports have used both PASS and OK across loader builds,
        # and some versions indent every result line. Accept both formats.
        $pass = @($lines | Where-Object { $_ -match '^\s*\[(?:PASS|OK)\]\s+' })
        $bad = @($lines | Where-Object { $_ -match '^\s*\[(?:SKIP|FAIL|ERROR)\]\s*' })
        $build = @($lines | Where-Object { $_ -match '^\s*\[XMod\] Build:' } | Select-Object -First 1)
        $hasCleanMarker = @($lines | Where-Object { $_ -match '^\s*State:\s*PREFLIGHT CLEAN\s*$' }).Count -eq 1
        # Older reports do not contain a State line. In those versions, an
        # empty blocked set plus a successful checker exit is the clean state.
        $clean = ($bad.Count -eq 0) -and (($hasCleanMarker) -or ($results[$side] -eq 0))
        $profile[$side] = [ordered]@{
            build = if ($build.Count) { $build[0] } else { 'unknown' }
            passed = $pass.Count
            clean = $clean
            processExitCode = $results[$side]
            blocked = @($bad)
        }
        $summary.Add("$side`: $($pass.Count) transformer modules passed")
        foreach ($line in $bad) { $blocked.Add("$side`: $line") }
        if (!$clean -or $results[$side] -ne 0) {
            if ($bad.Count -eq 0) { $blocked.Add("$side`: preflight did not finish cleanly") }
        }
    }

    $profilePath = Join-Path $archive 'compatibility-profile.json'
    $profile | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $profilePath -Encoding UTF8
    Copy-Item -LiteralPath $profilePath -Destination (Join-Path $reportDir 'latest-daily-profile.json') -Force

    if ($blocked.Count -eq 0) {
        return [pscustomobject]@{
            Success = $true
            Text = (($summary -join "`r`n") + "`r`n`r`nAll enabled mods passed bytecode structure and linkage checks. This daily can run without rebuilding the mods.`r`n`r`nProfile: $profilePath")
        }
    }
    $short = @($blocked | Select-Object -First 14)
    $more = if ($blocked.Count -gt $short.Count) { "`r`n...and $($blocked.Count - $short.Count) more; see the archived reports." } else { '' }
    return [pscustomobject]@{
        Success = $false
        Text = (($summary -join "`r`n") + "`r`n`r`nThis daily changed code used by one or more mods. Those mods remain blocked; no unsafe fingerprint override was installed.`r`n`r`n" + ($short -join "`r`n") + $more + "`r`n`r`nReports: $archive")
    }
}

if ($RunNow) {
    $result = Invoke-CompatibilityUpdate
    Write-Output $result.Text
    if (!$result.Success) { exit 2 }
    exit 0
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = 'XMage Daily Compatibility Updater'
$form.Size = New-Object System.Drawing.Size(760, 520)
$form.StartPosition = 'CenterScreen'
$form.MinimumSize = New-Object System.Drawing.Size(650, 420)

$intro = New-Object System.Windows.Forms.Label
$intro.AutoSize = $false
$intro.Location = New-Object System.Drawing.Point(18, 16)
$intro.Size = New-Object System.Drawing.Size(708, 55)
$intro.Text = 'Select the new XMage installation in the Mod Loader first, then click Update. The updater accepts snapshots only when every enabled transformer passes structural and linkage checks.'
$form.Controls.Add($intro)

$update = New-Object System.Windows.Forms.Button
$update.Location = New-Object System.Drawing.Point(18, 78)
$update.Size = New-Object System.Drawing.Size(220, 38)
$update.Text = 'Update Daily Compatibility'
$form.Controls.Add($update)

$openReports = New-Object System.Windows.Forms.Button
$openReports.Location = New-Object System.Drawing.Point(250, 78)
$openReports.Size = New-Object System.Drawing.Size(140, 38)
$openReports.Text = 'Open Reports'
$form.Controls.Add($openReports)

$output = New-Object System.Windows.Forms.TextBox
$output.Location = New-Object System.Drawing.Point(18, 130)
$output.Size = New-Object System.Drawing.Size(708, 330)
$output.Anchor = 'Top,Bottom,Left,Right'
$output.Multiline = $true
$output.ReadOnly = $true
$output.ScrollBars = 'Both'
$output.Font = New-Object System.Drawing.Font('Consolas', 9)
$output.Text = 'Ready. Existing reports are archived before each check.'
$form.Controls.Add($output)

$openReports.Add_Click({
    New-Item -ItemType Directory -Force -Path $historyDir | Out-Null
    Start-Process explorer.exe -ArgumentList $historyDir
})

$update.Add_Click({
    $update.Enabled = $false
    $output.Text = 'Checking the selected daily snapshot. This can take a few minutes...'
    $form.Refresh()
    try {
        $result = Invoke-CompatibilityUpdate
        $output.Text = $result.Text
        if ($result.Success) { $output.BackColor = [System.Drawing.Color]::Honeydew }
        else { $output.BackColor = [System.Drawing.Color]::MistyRose }
    } catch {
        $output.BackColor = [System.Drawing.Color]::MistyRose
        $output.Text = "Updater failed safely. No compatibility override was installed.`r`n`r`n$($_.Exception.Message)"
    } finally {
        $update.Enabled = $true
    }
})

[void]$form.ShowDialog()
