XMage Loader Daily Compatibility Button + November 8 Port
=========================================================

Extract this overlay into the Friends Edition root and replace files when
prompted. Open the normal XMage Mod Loader. The "Update Daily Compatibility"
button appears beside "Check Compatibility".

This overlay also updates int-migration-63-rebuild.jar for the XMage 1.4.63
snapshot built 2026-11-08T08:43:15Z (daily-2026-11-08-0848). Both client and
server pass all enabled structural and linkage checks with that snapshot.

Select the downloaded XMage daily in the loader, close any running client or
server, and click Update Daily Compatibility. Reports are stored under:

xmage-mod-loader\reports\snapshot-guard\daily-history

Future code-shape changes remain blocked until their transformers are reviewed.
