XMage Loader Daily Compatibility + Numeric64 Fixes
==================================================

Extract into the Friends Edition root and replace files when prompted.

Included:
- Loader compatibility button and corrected client/server result routing.
- November 8 daily PlayerImpl compatibility profile.
- Bulk Counter Accelerator 0.1.8 dynamic watcher audit.
- Unimplemented Cards 0.7.20: Infinity Elemental commits tagged infinite life
  through PlayerImpl.setLongLife(long), using the 64-bit min/max sentinels in
  PlayerView instead of Integer.MIN_VALUE/Integer.MAX_VALUE.

The legacy combat damage log still uses XMage's int carrier. Generic finite
long combat requires the separate CombatGroup/damage ABI migration.
