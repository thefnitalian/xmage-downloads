XMage Daily Compatibility Updater
=================================

1. Open the XMage Mod Loader and select the newly downloaded XMage daily.
2. Close the client and server.
3. Double-click UPDATE-DAILY-COMPATIBILITY.bat.
4. Click Update Daily Compatibility.

The updater archives the old reports, checks both client and server, runs the
loader's transformer structure and linkage checks, and writes a JSON profile
under xmage-mod-loader\reports\snapshot-guard\daily-history.

If every enabled mod passes, the existing mod JARs can be used with that daily
without rebuilding. If a method, field, or bytecode shape changed, the affected
mod remains blocked and the report explains what must be ported. The updater
does not replace hashes blindly because that can allow corrupt bytecode to load.

Current November 8 note: mage.players.PlayerImpl changed in code used by the
life migration. That snapshot requires a transformer port; it is not a safe
hash-only compatibility update.
