XMage Loader Daily Compatibility + November 8 + Counter Batcher
===============================================================

Extract into the Friends Edition root and replace files when prompted.

Included:
- Loader "Update Daily Compatibility" button and corrected client/server table.
- November 8 daily PlayerImpl compatibility profile.
- Bulk Counter Accelerator 0.1.8 with dynamic watcher auditing. Unrelated
  card-specific watchers no longer disable batching for the entire game.

Counter-aware watchers, individual counter triggers, replacements, and rule
modifiers still use native per-counter handling so their rules behavior remains
correct. Compatibility reports are archived under:

xmage-mod-loader\reports\snapshot-guard\daily-history
