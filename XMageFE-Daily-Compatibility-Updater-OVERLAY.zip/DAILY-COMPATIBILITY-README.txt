XMage Loader Daily Compatibility Button
=======================================

Extract this overlay into the Friends Edition root and replace mage-loader.jar
when prompted. Open the normal XMage Mod Loader. A new "Update Daily
Compatibility" button appears beside "Check Compatibility".

Select the newly downloaded XMage daily in the loader, close any running client
or server, and click the new button. The updater archives previous reports,
checks both sides, and writes its results under:

xmage-mod-loader\reports\snapshot-guard\daily-history

A snapshot is accepted only when enabled transformers pass their bytecode
structure and linkage checks. Code-shape changes remain blocked and are listed
in the report; the updater never enables them by blindly replacing fingerprints.
