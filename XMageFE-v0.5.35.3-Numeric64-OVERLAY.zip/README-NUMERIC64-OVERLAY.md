# XMage Friends Edition — November 7 daily rebuild

This candidate rebuilds the mod loader for XMage `daily-2026-11-07-2132`,
source commit `7a7976f3870c6e82287b075bacb88c4a4433d70a`.

## Rebased components

- The numeric migration module is pinned to the exact server and client class
  files shipped by this daily. Unknown snapshots still fail closed.
- The guarded bulk-counter transformer is reviewed and pinned to this daily's
  `CardImpl` class.
- A new exact-build common-effects module migrates the shared life gain/loss,
  target damage, power/toughness boost, target-counter, and dynamic-mana
  producers to the long APIs. Damage and permanent counters retain bounded
  chunking so existing replacement effects and event handling still run.
- All 18 enabled server modules and all 17 enabled client modules pass loader
  preflight with no skipped modules.

## Runtime verification

The candidate passed JVM verification and 192 focused assertions covering long
counter and mana arithmetic, views and serialization, long event amounts,
life mutation/replacement/event behavior, batch life loss, power/toughness,
exact permanent damage storage and clearing, shared effect consumers, bounded
damage chunks, and dynamic mana production. Tests exercise values from
3,000,000,000 through `Long.MAX_VALUE` where meaningful. All 12 newly rewritten
classes also pass `-Xverify:all` before packaging.

## Current migration boundary

This is an additive compatibility migration. Exact long storage and explicit
long APIs work in the transformed engine, while the original XMage `int` APIs
remain as saturating compatibility projections. The common effect classes
listed above can now originate values above 2,147,483,647. Specialized card
and engine effects that bypass those shared classes still use their original
`int` call sites and must be migrated as additional exact-build transformers.

Use this package only with the named daily snapshot. Run
`VERIFY-LIFE-MANA64.bat` after setup and stop if any module is reported skipped.

After installing new card modules, run `REBUILD-CARD-CATALOG.bat` once with
the client and server closed. Start both sides and let the first card scan
finish before creating a game. The scan rebuilds XMage's local `cards.h2`
catalogs; interrupting it can make registered cards appear to be missing.
