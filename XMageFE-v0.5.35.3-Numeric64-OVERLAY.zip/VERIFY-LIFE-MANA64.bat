@echo off
setlocal
set "ROOT=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%ROOT%VERIFY-LIFE-MANA64.ps1" %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo [XMageFE] 64-bit compatibility failed. Run SETUP.bat, then retry.
echo [XMageFE] Logs: reports\FRIENDS64-RESULT.txt
pause
exit /b %RC%
