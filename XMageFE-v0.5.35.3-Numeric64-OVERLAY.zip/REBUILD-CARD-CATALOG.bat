@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~dp0"
set "LOADER=%ROOT%xmage-mod-loader"
set "SELECTION=%LOADER%\config\xmage-selection.txt"
if not exist "%SELECTION%" (
  echo Missing XMage selection: %SELECTION%
  echo Run SETUP.bat first.
  exit /b 2
)
set /p XMAGE_ROOT=<"%SELECTION%"
if "%XMAGE_ROOT%"=="" (
  echo XMage selection is empty. Run SETUP.bat first.
  exit /b 2
)
for %%S in (client server) do (
  set "DB=%XMAGE_ROOT%\xmage\mage-%%S\db\cards.h2"
  if exist "!DB!.mv.db" (
    echo Backing up %%S card catalog...
    copy /y "!DB!.mv.db" "!DB!.mv.db.before-numeric64-rebuild" >nul
  )
  if exist "!DB!.trace.db" copy /y "!DB!.trace.db" "!DB!.trace.db.before-numeric64-rebuild" >nul
  if exist "!DB!.lock.db" del /q "!DB!.lock.db"
  if exist "!DB!.mv.db" del /q "!DB!.mv.db"
  if exist "!DB!.trace.db" del /q "!DB!.trace.db"
)
echo.
echo Card catalogs cleared for both client and server.
echo Start the server and client once and allow startup to finish completely.
echo The first startup rebuilds the catalog and may take several minutes.
echo Do not close either process while the DB scan is running.
exit /b 0
