﻿param(
    [string]$LoaderPath,
    [string]$GamePath,
    [string]$JavaPath
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $LoaderPath) { $LoaderPath = $here }
$selected = (Resolve-Path -LiteralPath $LoaderPath -ErrorAction Stop).ProviderPath.TrimEnd('\')
if (Test-Path -LiteralPath (Join-Path $selected 'xmage-mod-loader\mods') -PathType Container) {
    $loader = Join-Path $selected 'xmage-mod-loader'
} elseif ((Split-Path $selected -Leaf) -eq 'xmage-mod-loader' -and (Test-Path -LiteralPath (Join-Path $selected 'mods') -PathType Container)) {
    $loader = $selected
} else { throw "Cannot find the mod loader in LoaderPath: $selected" }
$loader = (Resolve-Path -LiteralPath $loader).ProviderPath.TrimEnd('\')
$expectedHashes = Get-Content -LiteralPath (Join-Path $here 'LIFE-MANA64-SHA256.json') -Raw | ConvertFrom-Json
foreach ($name in @('int-migration-63-rebuild.jar','life64-game-rules.jar','mana64-core.jar','player-counters-64.jar','numeric64-inspector.jar','numeric64-common-effects.jar','card-catalog-repair.jar')) {
    $file = Join-Path $loader "mods\$name"
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing 64-bit mod: $file" }
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
    $expected = [string]$expectedHashes.PSObject.Properties[$name].Value
    if ($actual -ne $expected) { throw "64-bit mod SHA-256 mismatch: $name" }
}
$selectionFile = Join-Path $loader 'config\xmage-selection.txt'
if ($GamePath) {
    $gameRoot = (Resolve-Path -LiteralPath $GamePath -ErrorAction Stop).ProviderPath.TrimEnd('\')
} elseif (Test-Path -LiteralPath $selectionFile -PathType Leaf) {
    $configured = (Get-Content -LiteralPath $selectionFile -TotalCount 1).Trim()
    if ($configured -eq 'auto') { throw 'Game selection is auto. Run SETUP.bat in this package to select XMage 1.4.63, or supply explicit -GamePath to verification.' }
    $gameRoot = (Resolve-Path -LiteralPath $configured -ErrorAction Stop).ProviderPath.TrimEnd('\')
} else {
    $gameRoot = Split-Path $loader -Parent
}
foreach ($side in @('client','server')) {
    foreach ($name in @('mage-1.4.63.jar', "mage-$side-1.4.63.jar")) {
        $jar = Join-Path $gameRoot "xmage\mage-$side\lib\$name"
        if (-not (Test-Path -LiteralPath $jar -PathType Leaf)) { throw "Missing required XMage engine: $jar" }
    }
}
if (Test-Path -LiteralPath $selectionFile -PathType Leaf) {
    $configured = (Get-Content -LiteralPath $selectionFile -TotalCount 1).Trim()
    if ($configured -ne $gameRoot) { throw "Loader selection ($configured) does not match GamePath ($gameRoot). Run the corrected installer to pin the right game." }
} else { throw "Missing configured game selection: $selectionFile. Run the corrected installer." }
$loaderJar = Join-Path $loader 'mage-loader.jar'
if (-not (Test-Path -LiteralPath $loaderJar -PathType Leaf)) { throw "Missing mage-loader.jar: $loaderJar" }
if ($JavaPath) {
    $java = (Resolve-Path -LiteralPath $JavaPath -ErrorAction Stop).ProviderPath
} else {
    $java = $null
    $javaSelection = Join-Path $loader 'config\java-selection.txt'
    if (Test-Path -LiteralPath $javaSelection -PathType Leaf) {
        $configuredJava = (Get-Content -LiteralPath $javaSelection -TotalCount 1).Trim()
        if ($configuredJava -and $configuredJava -ne 'auto') {
            foreach ($candidate in @($configuredJava, (Join-Path (Split-Path $loader -Parent) $configuredJava))) {
                if (Test-Path -LiteralPath $candidate -PathType Leaf) { $java = (Resolve-Path -LiteralPath $candidate).ProviderPath; break }
            }
        }
    }
    if (-not $java) {
        foreach ($candidate in @((Join-Path (Split-Path $loader -Parent) 'Java\bin\java.exe'), (Join-Path $gameRoot 'Java\bin\java.exe'))) {
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { $java = (Resolve-Path -LiteralPath $candidate).ProviderPath; break }
        }
    }
    if (-not $java) { $java = (Get-Command java -ErrorAction Stop).Source }
}
$reportsDir = Join-Path $here 'reports'
New-Item -ItemType Directory -Path $reportsDir -Force | Out-Null
$summary = New-Object 'System.Collections.Generic.List[string]'
$summary.Add('XMage Friends Edition v0.5.26.1 FULL mod-loader compatibility result')
$summary.Add(('Local test time: {0}' -f (Get-Date -Format o)))
$summary.Add(('Loader: {0}' -f $loader))
$summary.Add(('Game: {0}' -f $gameRoot))
$summary.Add(('Java: {0}' -f $java))
$summary.Add('PASS is preflight only, not proof of full gameplay or bulk payment.')
$allPassed = $true
foreach ($side in @('server', 'client')) {
    $work = Join-Path $gameRoot "xmage\mage-$side"
    $log = Join-Path $reportsDir "compatibility-$side.txt"
    $args = @('-Xverify:all', "-Dxmod.home=$loader", '-Dfile.encoding=UTF-8', '--add-exports=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED', '-jar', $loaderJar, 'check', $side)
    Push-Location $work
    try {
        $ErrorActionPreference = 'Continue'
        & $java @args *> $log
        $rc = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = 'Stop'
        Pop-Location
    }
    $content = Get-Content -LiteralPath $log -Raw
    $expected = if ($side -eq 'server') { @('int-migration-63-rebuild','life64-game-rules','mana64-core','player-counters-64','numeric64-common-effects','card-catalog-repair') }
                else { @('int-migration-63-rebuild','mana64-core','player-counters-64','numeric64-inspector') }
    $summary.Add('')
    $summary.Add(('{0} loader exit code: {1}' -f $side.ToUpperInvariant(), $rc))
    if ($rc -ne 0) { $allPassed = $false }
    foreach ($id in $expected) {
        $pattern = '(?m)^\s+\[OK\]\s+' + [regex]::Escape($id) + '\s+'
        $ok = $content -match $pattern
        if (-not $ok) { $allPassed = $false }
        $summary.Add(('{0}: {1}' -f $id, $(if ($ok) { 'OK' } else { 'NOT VERIFIED (see detailed log)' })))
    }
    Write-Host "Saved $side compatibility log: $log"
}
$summary.Add('')
$summary.Add(('Overall preflight: {0}' -f $(if ($allPassed) {'PASS'} else {'FAIL'})))
$report = Join-Path $reportsDir 'FRIENDS64-RESULT.txt'
$summary | Set-Content -LiteralPath $report -Encoding UTF8
$summary | ForEach-Object { Write-Host $_ }
Write-Host "Send back: $report"
if (-not $allPassed) { exit 1 }
exit 0
